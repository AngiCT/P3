import java.time.LocalDateTime;
import java.time.Duration;

public class BookInfo {

	private String  title;
	private String author;
	private String series;
	private int pages;
	private boolean finished;
	private String startDate;
	private String   endDate;

	private static final int  TITLE_LIMIT = 32;
	private static final int AUTHOR_LIMIT = 32;
	private static final int SERIES_LIMIT = 32;
	private static final int   DATE_LIMIT = 10;

	public static final int SIZE = 0; /* TO-DO: SET CORRECT VALUE */

	public BookInfo (String title, String author, String series, int pages,
	                 boolean finished, String startDate, String endDate) {
		this.title = title;
		this.author = author;
		this.series = series;
		this.pages = pages;
		this.finished = finished;
		this.startDate = startDate;
		this.endDate = endDate;
	}

	// Getters
	public String getTitle     () { return  title;    }
	public String getAuthor    () { return  author;   }
	public String getSeries    () { return  series;   }
	public   int  getPages     () { return  pages;    }
	public boolean isFinished  () { return finished;  }
	public String getStartDate () { return startDate; }
	public String getEndDate   () { return   endDate; }

	public byte[] toBytes() {
		byte[] record = new byte[SIZE];
		throw new UnsupportedOperationException ("TO-DO");
		// return record;
	}

	public static BookInfo fromBytes (byte[] record) {
		throw new UnsupportedOperationException ("TO-DO");
		// return new BookInfo (...);
	}

	public int daysToRead() {
		if (finished) {
			LocalDateTime start = LocalDateTime.parse (startDate + "T00:00:00");
			LocalDateTime  end  = LocalDateTime.parse (  endDate + "T00:00:00");
			Duration duration = Duration.between (start, end);
			return (int)duration.toDays() + 1;
		} else {
			return -1;
		}
	}

	public String toString() {
		String result = title
		              + " (" + series + ")"
		              + " by " + author
		              + " with " + pages + " pages.";
		if (finished) {
			result += " Read from " + startDate + " to " + endDate + ".";
		} else if (!startDate.isEmpty​()) {
			result += " Started on " + startDate + ".";
		}
		return result;
	}

}
