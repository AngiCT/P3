import java.io.FileReader;
import java.io.BufferedReader;
import java.io.IOException;

public class BookInfoReader {

	public static BookInfo readBookFile (String fileName) throws IOException {
		throw new UnsupportedOperationException ("TO-DO");
		// return new BookInfo (...);
	}

}
